//
//  main.m
//  Hicon
//
//  Created by Puneet Rao on 15/05/2013.
//  Copyright (c) 2013 Puneet Rao. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "HIconAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([HIconAppDelegate class]));
    }
}
