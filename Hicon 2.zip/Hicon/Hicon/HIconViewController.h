//
//  HIconViewController.h
//  Hicon
//
//  Created by Puneet Rao on 15/05/2013.
//  Copyright (c) 2013 Puneet Rao. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HemsUrlToImage.h"
@interface HIconViewController : UIViewController <UITableViewDelegate,UITableViewDataSource,HemsUrlToImageDelegate>
{
    NSMutableArray *imArray,*imArray2;
    IBOutlet UITableView *tbv;
    IBOutlet UITableView *tbv2;
    HemsUrlToImage *urlTbv,*urlAnother;
}
@property (retain, nonatomic) IBOutlet UIImageView *img;

@end
