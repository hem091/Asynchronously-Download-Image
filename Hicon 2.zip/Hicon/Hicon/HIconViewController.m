//
//  HIconViewController.m
//  Hicon
//
//  Created by Puneet Rao on 15/05/2013.
//  Copyright (c) 2013 Puneet Rao. All rights reserved.
//
#import "HIconViewController.h"
#import "IconDownloader.h"

@interface HIconViewController ()

@end

@implementation HIconViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    imArray = [[NSMutableArray alloc] init];
    
    for(int i=0;i<50;i++)
    {
        if(i%5 == 0)
            [imArray addObject:@"https://static.propertytalker.com/suburb_multimedia/thumbs/5190d5762e9a8.jpg"];
        else if(i%5 == 1)
            [imArray addObject:@"http://charcoaldesign.co.uk/AsyncImageView/Forest/IMG_0351.JPG"];
        else if(i%5 == 2)
            [imArray addObject:@"http://charcoaldesign.co.uk/AsyncImageView/Forest/IMG_0356.JPG"];
        else if(i%5 == 3)
            [imArray addObject:@"http://charcoaldesign.co.uk/AsyncImageView/Forest/IMG_0357.JPG"];
        else if(i%5 == 4)
            [imArray addObject:@"http://charcoaldesign.co.uk/AsyncImageView/Forest/IMG_0358.JPG"];
    }
    urlTbv = [[HemsUrlToImage alloc] init];
    urlTbv.delegate = self;
    urlTbv.identifier = @"scroll1";
    //Identifier to differentiate between different downloads
    //urlTbv.isNoCaching = YES;
    //Make it YES if you do not want caching otherwise NO or do not write this line
//    url.isSmallSize = YES;
    // This will download image in icon size of 100X100, Make it YES if you do want small size otherwise NO or do not write this line
    [urlTbv preSetImageArrayFromUrlArray:imArray];
    
    imArray2 = [[NSMutableArray alloc] initWithArray:imArray];
    urlAnother = [[HemsUrlToImage alloc] init];
    urlAnother.delegate = self;
    urlAnother.identifier = @"scroll2";
    //urlAnother.isNoCaching = YES;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [imArray count];
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(tableView == tbv){
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"CellNew"];
        if(cell == nil)
        {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"CellNew"];
            UIImageView *imgVw = [[UIImageView alloc] initWithFrame:CGRectMake(5, 5, 70, 70)];
            imgVw.tag = 1;
            
            UILabel *lblName = [[UILabel alloc] initWithFrame:CGRectMake(80, 0, 220, 80)];
            lblName.font = [UIFont boldSystemFontOfSize:16];
            lblName.backgroundColor = [UIColor clearColor];
            lblName.textColor = [UIColor whiteColor];
            lblName.tag = 2;
            [cell.contentView addSubview:imgVw];
            [cell.contentView addSubview:lblName];
        }
        UIImageView *imgVw = (UIImageView*)[cell.contentView viewWithTag:1];
        UILabel *lblName = (UILabel*)[cell.contentView viewWithTag:2];
        lblName.text = [NSString stringWithFormat:@"Image %d",indexPath.row+1];
        imgVw.image = nil;
        //NSLog(@"%@",imArray);
        if([[imArray objectAtIndex:indexPath.row] isKindOfClass:NSClassFromString(@"UIImage")])
            imgVw.image = [imArray objectAtIndex:indexPath.row];
        return cell;
    }
    else{
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"CellNew"];
        if(cell == nil)
        {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"CellNew"];
            UIImageView *imgVw = [[UIImageView alloc] initWithFrame:CGRectMake(5, 5, 70, 70)];
            imgVw.tag = 1;
            
            UILabel *lblName = [[UILabel alloc] initWithFrame:CGRectMake(80, 0, 220, 80)];
            lblName.font = [UIFont boldSystemFontOfSize:16];
            lblName.backgroundColor = [UIColor clearColor];
            lblName.textColor = [UIColor whiteColor];
            lblName.tag = 2;
            [cell.contentView addSubview:imgVw];
            [cell.contentView addSubview:lblName];
        }
        UIImageView *imgVw = (UIImageView*)[cell.contentView viewWithTag:1];
        UILabel *lblName = (UILabel*)[cell.contentView viewWithTag:2];
        lblName.text = [NSString stringWithFormat:@"Image %d",indexPath.row+1];
        imgVw.image = nil;
        NSLog(@"%@",imArray2);
        if([[imArray2 objectAtIndex:indexPath.row] isKindOfClass:NSClassFromString(@"UIImage")])
        {
            imgVw.image = [imArray2 objectAtIndex:indexPath.row];
        }
        else
        {
            [urlAnother dynamicSetImageFromUrl:imArray2 withIndex:indexPath.row];
        }
        return cell;
    }
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - HemsUrlToImageDelegate
-(void)urlToImageConverted:(NSArray *)convertedArray withIdentifier:(NSString *)identifier andIndex:(NSInteger)indexNumber
{
    if([identifier isEqualToString:@"scroll1"])
    {
        imArray = [[NSMutableArray alloc] initWithArray:convertedArray];
        [tbv reloadData];
    }
    else{
        imArray2 = [[NSMutableArray alloc] initWithArray:convertedArray];
        [tbv2 reloadData];
    }
}
- (void)dealloc {
    [_img release];
    [tbv release];
    [tbv2 release];
    [super dealloc];
}
@end
